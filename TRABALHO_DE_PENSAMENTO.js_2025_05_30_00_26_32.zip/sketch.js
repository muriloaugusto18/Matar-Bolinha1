let player;

let bullets = [];

let enemies = [];

let score = 0;

let gameOver = false;

function setup() {

  createCanvas(400, 600);

  player = new Player();

  setInterval(spawnEnemy, 1000);

}

function draw() {

  background(0);

  if (gameOver) {

    textSize(32);

    fill(255, 0, 0);

    textAlign(CENTER, CENTER);

    text("Game Over", width / 2, height / 2);

    textSize(24);

    text("Score: " + score, width / 2, height / 2 + 40);

    return;

  }

  player.show();

  player.move();

  // Balas

  for (let i = bullets.length - 1; i >= 0; i--) {

    bullets[i].update();

    bullets[i].show();

    // Remover balas fora da tela

    if (bullets[i].offscreen()) {

      bullets.splice(i, 1);

    }

  }

  // Inimigos

  for (let i = enemies.length - 1; i >= 0; i--) {

    enemies[i].update();

    enemies[i].show();

    // Verifica colisão com as balas

    for (let j = bullets.length - 1; j >= 0; j--) {

      if (enemies[i].hits(bullets[j])) {

        enemies.splice(i, 1);

        bullets.splice(j, 1);

        score++;

        break;

      }

    }

    // Verifica se algum inimigo passou

    if (i < enemies.length && enemies[i].y > height) {

      gameOver = true;

    }

  }

  fill(255);

  textSize(20);

  text("Score: " + score, 10, 25);

}

function keyPressed() {

  if (keyCode === LEFT_ARROW) {

    player.setDir(-1);

  } else if (keyCode === RIGHT_ARROW) {

    player.setDir(1);

  } else if (key === ' ') {

    bullets.push(new Bullet(player.x + player.w / 2, player.y));

  }

}

function keyReleased() {

  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {

    player.setDir(0);

  }

}

function spawnEnemy() {

  if (!gameOver) {

    enemies.push(new Enemy());

  }

}

// Classes

class Player {

  constructor() {

    this.x = width / 2;

    this.y = height - 40;

    this.w = 40;

    this.h = 20;

    this.dir = 0;

  }

  show() {

    fill(0, 255, 255);

    rect(this.x, this.y, this.w, this.h);

  }

  setDir(dir) {

    this.dir = dir;

  }

  move() {

    this.x += this.dir * 5;

    this.x = constrain(this.x, 0, width - this.w);

  }

}

class Bullet {

  constructor(x, y) {

    this.x = x;

    this.y = y;

    this.r = 5;

  }

  update() {

    this.y -= 10;

  }

  show() {

    fill(255);

    ellipse(this.x, this.y, this.r * 2);

  }

  offscreen() {

    return this.y < 0;

  }

}

class Enemy {

  constructor() {

    this.x = random(width - 30);

    this.y = 0;

    this.r = 15;

    this.speed = 3;

  }

  update() {

    this.y += this.speed;

  }

  show() {

    fill(255, 0, 0);

    ellipse(this.x, this.y, this.r * 2);

  }

  hits(bullet) {

    let d = dist(this.x, this.y, bullet.x, bullet.y);

    return d < this.r + bullet.r;

  }

}